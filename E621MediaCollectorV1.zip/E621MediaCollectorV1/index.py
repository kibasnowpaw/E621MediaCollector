import os
import json
import time
import requests
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm


class E621Downloader:
    def __init__(self, config_file='config.json', tags_file='tags.txt', delay=5, num_threads=5, max_attempts=3):
        self.config = self.load_config(config_file)
        self.tags = self.load_tags(tags_file)
        self.endpoint_url = "https://e621.net/posts.json"
        self.download_folder = "Downloaded"
        self.headers = {
            "User-Agent": "MyProject/1.0 (by username on e621)",  # Update the User-Agent here
            "login": self.config['Username'],
            "api_key": self.config['APIKey']
        }
        self.delay = delay
        self.downloaded_files = set()
        self.num_threads = num_threads
        self.max_attempts = max_attempts

    def load_config(self, config_file):
        with open(config_file) as file:
            return json.load(file)

    def load_tags(self, tags_file):
        with open(tags_file) as file:
            return [line.strip() for line in file if line.strip()]

    def create_download_folder(self):
        os.makedirs(self.download_folder, exist_ok=True)
        for root, dirs, files in os.walk(self.download_folder):
            for file in files:
                self.downloaded_files.add(file)

    def download_content(self, media_url, tag):
        if media_url is None:
            print(f"Skipping download for tag: {tag}. Media URL is missing.")
            return

        file_name = os.path.basename(media_url)
        folder_name = tag.replace(' ', '_')
        folder_path = os.path.join(self.download_folder, folder_name)
        file_path = os.path.join(folder_path, file_name)

        os.makedirs(folder_path, exist_ok=True)  # Create folder with tag name if it doesn't exist

        if file_name in self.downloaded_files:
            print(f"Skipping download for file: {file_name}. Already downloaded.")
            return

        print(f"Downloading {file_name} with tag: {tag}...")
        attempts = 0
        while attempts < self.max_attempts:
            try:
                response = requests.get(media_url, stream=True)
                response.raise_for_status()
                total_size = int(response.headers.get('Content-Length', 0))

                with open(file_path, "wb") as file, tqdm.wrapattr(
                    file,
                    "write",
                    total=total_size,
                    desc=file_name,
                    unit="B",
                    unit_scale=True,
                    ncols=80,
                ) as progress_file:
                    file.write(response.content)

                self.downloaded_files.add(file_name)
                print("Download complete!")

                # Generate .nfo file
                self.generate_nfo_file(file_path, tag, media_url)

                return
            except requests.exceptions.SSLError as e:
                print(f"SSL handshake failed. Make sure the SSL certificate is valid.")
                break
            except requests.exceptions.HTTPError as e:
                print(f"Failed to download media. Retrying...")
                attempts += 1
                time.sleep(self.delay)
            except Exception as e:
                print(f"An unexpected error occurred: {e}")
                break

        print(f"Failed to download {file_name} with tag: {tag} after {self.max_attempts} attempts.")

    def generate_nfo_file(self, file_path, tag, media_url):
        file_name = os.path.basename(file_path)
        nfo_file_path = file_path + ".nfo"

        # Delete old .nfo file if it exists
        if os.path.exists(nfo_file_path):
            os.remove(nfo_file_path)

        with open(nfo_file_path, "w") as nfo_file:
            nfo_file.write("File: {}\n".format(file_name))
            nfo_file.write("Tag: {}\n".format(tag))
            nfo_file.write("URL: {}\n".format(media_url))
            nfo_file.write("\n")

            response = requests.get(media_url, headers=self.headers)
            response.raise_for_status()
            data = response.json()

            if "artist" in data:
                artists = data["artist"]
                nfo_file.write("Artist: {}\n".format(", ".join(artists)))
            if "source" in data:
                source = data["source"]
                nfo_file.write("Source: {}\n".format(source))
            if "tags" in data:
                tags = data["tags"]["general"]
                nfo_file.write("Tags: {}\n".format(", ".join(tags)))

    def make_api_request(self, url, params):
        try:
            posts = []
            total_count = None
            retrieved_count = 0

            while total_count is None or retrieved_count < total_count:
                response = requests.get(url, params=params, headers=self.headers)
                response.raise_for_status()
                data = response.json()
                new_posts = [post for post in data.get("posts", []) if post.get("file", {}).get("url")]
                posts.extend(new_posts)

                if total_count is None:
                    total_count = data.get("total", 0)

                retrieved_count = len(posts)

                params["page"] += 1
                time.sleep(self.delay)

            return {"posts": posts, "total_count": total_count}
        except requests.exceptions.HTTPError as e:
            print(f"API request failed with error: {e}")
            if response.status_code == 429:
                print("Rate limit exceeded. Slow down your requests.")
        except requests.exceptions.RequestException as e:
            print(f"An error occurred during the API request: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
        return None

    def download_posts(self, posts, tag):
        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            futures = []
            for post in posts:
                media_url = post["file"]["url"]
                futures.append(executor.submit(self.download_content, media_url, tag))

            for future in tqdm(
                futures,
                total=len(futures),
                desc=f"Downloading {tag} posts",
                ncols=80,
            ):
                future.result()

    def run(self):
        self.create_download_folder()

        for tag in self.tags:
            print(f"Searching for posts with tag: {tag}...")
            params = {
                "tags": tag,
                "limit": 320,
                "page": 1
            }
            response = self.make_api_request(self.endpoint_url, params)

            if response is not None and response["posts"]:
                self.download_posts(response["posts"], tag)
            else:
                print(f"No posts found with tag: {tag}.")


if __name__ == "__main__":
    downloader = E621Downloader()
    downloader.run()
